<?php
session_start();
if (!isset($_SESSION['zalogowany'])){$_SESSION['zalogowany'] = false;}
if($_SESSION['zalogowany'] == false){header('Location: ../index.php');};
?>
<html>
<head>
<title>Zadania</title>
<link rel="shortcut icon" href="icon.ico" />
<meta http-equiv='content-type' content='text/html; charset=utf-8'/>
</head>
<body lang='pl-PL' text='#000000' bgcolor='#deeaf6' dir='ltr'>
<?php
$czas = date("d.m.Y  H:i:s");
echo($czas);
?>
<center>
<h3>Wybierz klasę</h3>
<br>
<form action='/1As/index.php'>
<h4 class='western' align='center'><input type='submit' value='1 As'></h4>
</form>
<br>
<form action='/1Bs/index.php'>
<h4 class='western' align='center'><input type='submit' value='1 Bs'></h4>
</form>
<br>
<form action='/1Cs/index.php'>
<h4 class='western' align='center'><input type='submit' value='1 Cs'></h4>
</form>
<br>
<form action='/1Ds/index.php'>
<h4 class='western' align='center'><input type='submit' value='1 Ds'></h4>
</form>
</center>
<br>
	<p align="right">&nbsp;</p>
	<a href='http://www.counterliczniki.com'>http://Counterliczniki.com</a> <script type='text/javascript' src='https://www.counterliczniki.com/auth.php?id=2606eee75ce4b319172cffa2c3ec0ddd5c41738f'></script>
	<script type="text/javascript" src="https://www.counterliczniki.com/pl/home/counter/680103/t/1"></script>
<br>
<p><span style="background: #c0c0c0"><sdfield type=DATETIME sdval="43912,7764592361" sdnum="1045;1045;D.MM.YYYY">Data ostatniej poprawki: 10.05.2020</sdfield></span></p>
</body>
</html>