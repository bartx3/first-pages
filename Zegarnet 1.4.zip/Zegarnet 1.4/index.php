<?php
session_start();
if (!isset($_SESSION['zalogowany'])){$_SESSION['zalogowany'] = false;}
if($_SESSION['zalogowany'] == true){header('Location: ../index1.php');};
?>
<?php
//setup php for working with Unicode data
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');
mb_http_input('UTF-8');
mb_language('uni');
mb_regex_encoding('UTF-8');
ob_start('mb_output_handler');
?>
<html>
<head>
<title>Logowanie</title>
	<link rel="shortcut icon" href="icon.ico" />
	<style type="text/css">
		td { border: 1px solid black; }
		td p { color: #000000 }
		p { color: #000000 }
		h2 { color: #000000 }
		h2.cjk { font-family: "NSimSun" }
		h2.ctl { font-family: "Lucida Sans" }
		h4 {color: #DC143C}
	</style>
<meta http-equiv='content-type' content='text/html; charset=utf-8'/>
</head>
<body lang='pl-PL' text='#000000' bgcolor='#E0CCFF' dir='ltr'>
	<p  align=right> <span style="background: #DDDDDD">
	<?php
	$czas = date("d.m.Y  H:i:s");
	echo($czas);
	?>
	</span></p>
	<center><br>
	<h2>Logowanie<h2>
	<br>
	<h3>Podaj hasło</h3>
	<form action="login.php" method="post">
	<input type="password" name='has'/>
	</form>
</body>
</html>