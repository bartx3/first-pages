<?php
$number=20;
$numerek='20' ;
?>