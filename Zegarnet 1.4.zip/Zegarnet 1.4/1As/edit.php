<?php
session_start();
if (!isset($_SESSION['zalogowany'])){$_SESSION['zalogowany'] = false;}
if($_SESSION['zalogowany'] != true){header('Location: ../index.php');};
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<?php
//setup php for working with Unicode data
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');
mb_http_input('UTF-8');
mb_language('uni');
mb_regex_encoding('UTF-8');
ob_start('mb_output_handler');
?>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title>Lista zadań - edycja</title>
	<link rel="shortcut icon" href="icon.ico" />
	<style type="text/css">
		td { border: 1px solid black; }
		td p { color: #000000 }
		p { color: #000000 }
		h2 { color: #000000 }
		h2.cjk { font-family: "NSimSun" }
		h2.ctl { font-family: "Lucida Sans" }
		h4 {color: #DC143C}
	</style>
</head>
<body lang="pl-PL" text="#000000" bgcolor="#deeaf6" dir="ltr">
<?php include 'data.php'; ?>
<form action="edited.php" method="post">
<h2 class="western" align="center">
<font size="7" style="font-size: 32pt">Lista zadań - edycja</font></h2>
<br>
<p class="western" align="center">
<p align="right">&nbsp;</p>
<center>
<!--	<h4>Nie używaj znaku '<br>Jego użycie skutkuje błędem krytycznym<br></h4>	-->
	<table width="90%" cellpadding="5" cellspacing="0" style="background: transparent">
		<col width="77*"/>

		<col width="141*"/>

		<col width="38*"/>

		<tr style="background: transparent" valign="top">
			<td width="30%" height="54" bgcolor="#f4b087" style="background: #f4b087" style="border: none; padding: 0cm"><p align="center" style="orphans: 153">
				<font face="Liberation Serif, serif"><font size="5" style="font-size: 20pt"><b>Przedmiot</b></font></font></p>
			</td>
			<td width="55%" bgcolor="#a8d08d" style="background: #a8d08d" style="border: none; padding: 0cm"><p align="center">
				<font size="5" style="font-size: 20pt"><b>Zadania</b></font></p>
			</td>
			<td width="15%" bgcolor="#ff9b9b" style="background: #ff9b9b" style="border: none; padding: 0cm"><p align="center">
				<font size="5" style="font-size: 20pt"><b>Termin</b></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Religia</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 15pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=1 ><?php echo htmlspecialchars($dane[1]); ?></textarea></font></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=2 ><?php echo htmlspecialchars($dane[2]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Po<font face="Liberation Serif, serif">ls</font>ki</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=3 ><?php echo htmlspecialchars($dane[3]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=4 ><?php echo htmlspecialchars($dane[4]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Historia</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=5 ><?php echo htmlspecialchars($dane[5]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=6 ><?php echo htmlspecialchars($dane[6]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>WOK</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=7 ><?php echo htmlspecialchars($dane[7]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=8 ><?php echo htmlspecialchars($dane[8]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Matematyka</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=9 ><?php echo htmlspecialchars($dane[9]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=10 ><?php echo htmlspecialchars($dane[10]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Fizyka</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=11 ><?php echo htmlspecialchars($dane[11]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=12 ><?php echo htmlspecialchars($dane[12]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Chemia</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=13 ><?php echo htmlspecialchars($dane[13]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=14 ><?php echo htmlspecialchars($dane[14]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Biologia</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=15 ><?php echo htmlspecialchars($dane[15]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=16 ><?php echo htmlspecialchars($dane[16]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Geografia</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=17 ><?php echo htmlspecialchars($dane[17]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=18 ><?php echo htmlspecialchars($dane[18]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Informatyka</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=19 ><?php echo htmlspecialchars($dane[19]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=20 ><?php echo htmlspecialchars($dane[20]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Przedsiębiorczość</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=21 ><?php echo htmlspecialchars($dane[21]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=22 ><?php echo htmlspecialchars($dane[22]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>EDB</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=23 ><?php echo htmlspecialchars($dane[23]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=24 ><?php echo htmlspecialchars($dane[24]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>WF</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=25 ><?php echo htmlspecialchars($dane[25]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=26 ><?php echo htmlspecialchars($dane[26]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Angielski grupa 1</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=27 ><?php echo htmlspecialchars($dane[27]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=28 ><?php echo htmlspecialchars($dane[28]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Angielski grupa 2</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=29 ><?php echo htmlspecialchars($dane[29]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=30 ><?php echo htmlspecialchars($dane[30]); ?></textarea></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>WOS</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=31 ><?php echo htmlspecialchars($dane[31]); ?></textarea></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.1cm">
				<font size="4" style="font-size: 16pt"><textarea style="font-family: 'Liberation Serif, serif'; width:100%; height:50%" name=32 ><?php echo htmlspecialchars($dane[32]); ?></textarea></font></p>
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="Potwierdź">
</center>
</form>
<p align="right">&nbsp;</p>
<p><span style="background: #c0c0c0"><sdfield type=DATETIME sdval="43912,7764592361" sdnum="1045;1045;D.MM.YYYY">Data ostatniej poprawki: 10.05.2020</sdfield></span></p>
</body>
</html>