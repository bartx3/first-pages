<?php
$number=25;
$numerek='25' ;
?>