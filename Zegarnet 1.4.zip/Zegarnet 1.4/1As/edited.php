<?php
session_start();
if (!isset($_SESSION['zalogowany'])){$_SESSION['zalogowany'] = false;}
if($_SESSION['zalogowany'] != true){header('Location: ../index.php');};
?>
<?php
//setup php for working with Unicode data
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');
mb_http_input('UTF-8');
mb_language('uni');
mb_regex_encoding('UTF-8');
ob_start('mb_output_handler');
//copy old data.php
copy("data_old.php","old_data.php");
copy("data.php", "data_old.php");

//load data from the form and create a new file
$fp = fopen ('data.php', 'w');

for($ii=1; $ii<=32; $ii=$ii+1){
	$zlyznak = array("\\", '\'');
	$dobryznak = array("\\\\", '\\\'');
	include '../cenzura.php';
	$XD=str_replace($zlyznak, $dobryznak, ($_POST[$ii]));
	$d[$ii]=str_replace($nie, $zamiast,$XD);
	
}

//create the new data
$new="<?php
//setup php for working with Unicode data
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');
mb_http_input('UTF-8');
mb_language('uni');
mb_regex_encoding('UTF-8');
ob_start('mb_output_handler');
";
for($i=1; $i<=32; $i=$i+1){
$new.="$"; $new.="dane[$i] ='"; $new.=$d[$i]; $new.="';";
$new.='
';
}
$new.="?>";

fwrite($fp, $new);
fclose($fp);

//check and edit save number
include 'nr zapisu.php';
$nr= "saves/";
$nr.= $numerek;
$nr.=".php";
copy("data.php", $nr);
$number = $number + 1;
if($number > 1000){$number = 1;}
$p = fopen ("nr zapisu.php", "w");
$n='<?php
$number=';
$n.=$number;
$n.=';
$numerek=\'';
$n.=$number;
$n.="' ;
?>";
fwrite($p, $n);
?>
<html>
<head>
<meta http-equiv='content-type' content='text/html; charset=utf-8'/>
</head>
<body lang='pl-PL' text='#000000' bgcolor='#deeaf6' dir='ltr'>
<form action='index.php'>
<center>
<br>
<p class='western' align='center'><input type='submit' value='Powrót na stronę główną'></p>
</form>
</center>
<p bottom: 0;><span style="background: #c0c0c0"><sdfield type=DATETIME sdval="43912,7764592361" sdnum="1045;1045;D.MM.YYYY">Data ostatniej poprawki: 10.05.2020</sdfield></span></p>
</body>
</html>