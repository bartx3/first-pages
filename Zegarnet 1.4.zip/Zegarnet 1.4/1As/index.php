<?php
session_start();
if (!isset($_SESSION['zalogowany'])){$_SESSION['zalogowany'] = false;}
if($_SESSION['zalogowany'] != true){header('Location: ../index.php');};
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Lista zadań</title>
	<link rel="shortcut icon" href="icon.ico" />
	<style type="text/css">
		td { border: 1px solid black; }
		td p { color: #000000 }
		p { color: #000000 }
		h2 { color: #000000 }
		h2.cjk { font-family: "NSimSun" }
		h2.ctl { font-family: "Lucida Sans" }
	</style>
</head>
<body lang="pl-PL" text="#000000" bgcolor="#deeaf6" dir="ltr"><?php include 'data.php';?>

<h2 class="western" align="center">
<font size="7" style="font-size: 32pt">Lista zadań</font></h2>
<p align="right">&nbsp;</p>
<center>
	<table width="90%" cellpadding="5" cellspacing="0" style="background: transparent">
		<col width="77*"/>

		<col width="141*"/>

		<col width="38*"/>

		<tr style="background: transparent" valign="top">
			<td width="30%" height="54" bgcolor="#f4b087" style="background: #f4b087" style="border: none; padding: 0cm"><p align="center" style="orphans: 153">
				<font face="Liberation Serif, serif"><font size="5" style="font-size: 20pt"><b>Przedmiot</b></font></font></p>
			</td>
			<td width="55%" bgcolor="#a8d08d" style="background: #a8d08d" style="border: none; padding: 0cm"><p align="center">
				<font size="5" style="font-size: 20pt"><b>Zadania</b></font></p>
			</td>
			<td width="15%" bgcolor="#ff9b9b" style="background: #ff9b9b" style="border: none; padding: 0cm"><p align="center">
				<font size="5" style="font-size: 20pt"><b>Termin</b></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Religia</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[1]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[2]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Po<font face="Liberation Serif, serif">ls</font>ki</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[3]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[4]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Historia</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[5]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[6]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>WOK</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[7]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[8]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Matematyka</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[9]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[10]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Fizyka</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[11]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[12]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Chemia</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[13]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[14]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Biologia</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[15]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[16]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Geografia</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[17]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[18]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Informatyka</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[19]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[20]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Przedsiębiorczość</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[21]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[22]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>EDB</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[23]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[24]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>WF</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[25]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[26]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Angielski grupa 1</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[27]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[28]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>Angielski grupa 2</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[29]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[30]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
		<tr style="background: transparent" valign="top">
			<td width="30%" bgcolor="#fbe4d5" style="background: #fbe4d5" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm; orphans: 51">
				<font size="4" style="font-size: 15pt"><b>WOS</b></font></p>
			</td>
			<td width="55%" bgcolor="#e2efd9" style="background: #e2efd9" style="border: none; padding: 0cm"><p align="left" style="margin-top: 0.1cm">
				<?php $tymczasowa = htmlspecialchars($dane[31]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></p>
			</td>
			<td width="15%" bgcolor="#ffe7e7" style="background: #ffe7e7" style="border: none; padding: 0cm"><p align="center" style="margin-top: 0.2cm">
				<font size="4" style="font-size: 16pt"><?php $tymczasowa = htmlspecialchars($dane[32]); $tymczasowa = str_replace("
",'<br>',$tymczasowa); echo $tymczasowa; ?></font></p>
			</td>
		</tr>
	</table>
<br>
<form action="edit.php">
<input type="submit" value="Edytuj">
</form>
</center>
<p align="right">&nbsp;</p>
<p><span style="background: #c0c0c0"><sdfield type=DATETIME sdval="43912,7764592361" sdnum="1045;1045;D.MM.YYYY">Data ostatniej poprawki: 10.05.2020</sdfield></span></p>
</body>
</html>