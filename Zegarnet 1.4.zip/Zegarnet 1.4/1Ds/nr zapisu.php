<?php
$number=28;
$numerek='28' ;
?>