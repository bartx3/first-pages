<?php
$number=19;
$numerek='19' ;
?>