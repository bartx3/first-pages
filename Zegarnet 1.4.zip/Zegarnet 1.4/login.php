<?php
session_start();
	if (!isset($_SESSION['zalogowany'])){$_SESSION['zalogowany'] = false;}
	if($_SESSION['zalogowany'] == false){
		$haslo = $_POST['has'];
		//$zlyznak = array("\\", '\'');
		//$dobryznak = array("\\\\", '\\\'');
		//$haslo = str_replace($zlyznak, $dobryznak, ($_POST['has']));
		$poprawne = 'information247';
		if($haslo == $poprawne){
			$_SESSION['zalogowany'] = true;
			header('Location: index1.php');
		}
		else{header ('Location: ../index.php');}
	}
	if($_SESSION['zalogowany'] == true){header('Location: index1.php');};
?>